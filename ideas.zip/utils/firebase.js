// firebase.js
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';

const firebaseConfig = {
  apiKey: 'AIzaSyCR4-xpQr30ySP6YHuFqjwTy22FFeL47us',
  authDomain: 'sticky-ideas-1ba92.firebaseapp.com',
  projectId: 'sticky-ideas-1ba92',
  storageBucket: 'sticky-ideas-1ba92.firebasestorage.app',
  messagingSenderId: '874517636396',
  appId: '1:874517636396:web:8d6edb54537f263c26f889',
  measurementId: 'G-W0E1FGB4P1',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
